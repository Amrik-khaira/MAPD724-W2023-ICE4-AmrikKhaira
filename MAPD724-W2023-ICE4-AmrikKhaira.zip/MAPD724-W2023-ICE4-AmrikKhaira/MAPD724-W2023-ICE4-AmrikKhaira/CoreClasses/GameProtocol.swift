//
//  GameProtocol.swift
//  Author's name : Amrik Singh
//  StudentID : 301296257
//
//  MAPD724-W2023-ICE4-AmrikKhaira
//
//  Created by Amrik on 12/02/23.
//

protocol GameProtocol
{
    // Initialization
    func Start()
    
    // Update every frame
    func Update()
    
    // Check if the position is outside the bounds of the Screen
    func CheckBounds()
    
    // A method to reset the position
    func Reset()
}
