import SpriteKit
import UIKit

class ScoreManager
{
    public static var Score: Int = 0
    public static var Lives: Int = 5
}
